package net.badlion.gcheat.gemu.events;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;


public class GCheatEvent extends PlayerEvent implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private String msg;
    private GCheatEvent.Type type;
    private GCheatEvent.Level level;
    private boolean cancelled = false;

    public GCheatEvent(Player player, Type type, Level level, String msg) {
        super(player);
        this.type = type;
        this.level = level;
        this.msg = msg;
    }

    public String getMsg() {
        return this.msg;
    }

    @Override
    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public Type getType() {
        return this.type;
    }

    public Level getLevel() {
        return this.level;
    }

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public static enum Level {
        CHAT_MOD,
        TRIAL,
        MOD,
        ADMIN,
        OP;


        private Level() {
        }
    }

    public static enum Type {
        SPEED,
        FLY,
        AUTO_CLICKER,
        KILL_AURA,
        HOVER,
        CRIT,
        NO_FALL,
        SPIDER,
        INVENTORY,
        TIMER,
        DEBUG,
        UNKNOWN,
        ANTI_KB,
        FREECAM,
        PHASE,
        FAST_EAT_MACHINE_GUN,
        REGEN;


        private Type() {
        }
    }

}


